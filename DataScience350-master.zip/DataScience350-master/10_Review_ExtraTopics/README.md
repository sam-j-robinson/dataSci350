http://nfmcclure.github.io/DataScience350
